CREATE TABLE products (
product_id int(11) NOT NULL auto_increment,
category_id int(11) NOT NULL,
product_name varchar(255) NOT NULL,
description text,
price decimal(10,2),
product_image varchar(255),
PRIMARY KEY (product_id),
KEY product_category_id (category_id)
);
