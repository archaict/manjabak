<?php
function redirect_to($location = NULL){
  if($location !=NULL){
    header("Location: {location}")
  }
}
function output_pesan($pesan=""){
  if(!empty($pesan)){
    return "<p class=\"pesan\">{$pesan}</p>";
    }else{
return "";
  }
}
?>

