<?php
class ContohSetterGetter{
  private $nilai =75;
  public function get_nilai(){
  return $this->nilai;
  }
  public function set_nilai($value){
  $this->nilai = $value;
  }
}

$settergetter = new ContohSetterGetter;
echo $settergetter->get_nilai();
echo "<br/>";
$settergetter->set_nilai(82);
echo $settergetter->get_nilai();
?>
