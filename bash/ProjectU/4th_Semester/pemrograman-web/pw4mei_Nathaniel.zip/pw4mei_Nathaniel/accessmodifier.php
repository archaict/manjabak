<?php
class Nilai{
	public $uts = 80;
	private $tugas = 100;
	protected $uas = 70;

	public function nilaiakhir(){
		echo "Nilai UTS; " . $this->uts;
		echo"<br/>";
		echo "Nilai Tugas: " . $this->tugas;
		echo "<br/>";
		echo "Nilai UAS: " . $this->uas;
		$total = $this->uts + $this->tugas + $this->uas;
		echo "<br/>";
		echo "Total: " . $total;
	}
}
	$nilai = new Nilai;
		echo "Nilai UTS; " . $nilai->uts;
		echo"<br/>";
		//echo "Nilai Tugas: " . $this->tugas;
		echo "<br/>";
		//echo "Nilai UAS: " . $nilai->uas;
		echo $nilai->nilaiakhir();
?>