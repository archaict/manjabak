<?php
class Mobil{
	var$pintu = 4;
	var$ban = 4;
	function pintudanban(){
		return $this->pintu + $this->ban;
	}
}
	class MobilTruk extends Mobil{
		var $pintu=2;
	}
$mobil = new Mobil;
echo "Jumlah Pintu: " . $mobil->pintu;
echo "<br/>";
echo "Jumlah ban: " . $mobil->ban;
echo "<br/>";
echo $mobil->pintudanban();
echo "<br/><hr/>";
$mobiltruk = new MobilTruk;
echo "<br/>";
echo "Jumlah pintu Truk: " . $mobiltruk->pintu;
echo "<br/>";
echo "Jumlah ban: truk" . $mobiltruk->ban;
echo "<br/>";
echo $mobil->pintudanban();
echo "<br/>";
echo "Bapaknya MobilTruk adalah: " . get_parent_class('MobilTruk');
?>