<?php

class Mahasiswa{
	static $jml_mahasiswa = 1;
	static function tambah(){
		$newjumlah = Self::$jml_mahasiswa;
		return $newjumlah;
	}
	static function selamat($smlt="Selamat Pagi"){
		echo "$smlt Mahasiswa Sekalian";
	}
}
/*$mhs = new Mahasiswa;
echo $mhs -> jml_mahasiswa;*/
echo Mahasiswa::$jml_mahasiswa;
echo "<br/>";
echo Mahasiswa::tambah();
echo "<br/>";
Mahasiswa::selamat("Selamat Siang");
?>
